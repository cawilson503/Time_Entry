﻿namespace Time_Entry
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Sun = new Label();
            SunText = new TextBox();
            MonText = new TextBox();
            TuesText = new TextBox();
            WedText = new TextBox();
            ThursText = new TextBox();
            FriText = new TextBox();
            SatText = new TextBox();
            Entry = new TextBox();
            Mon = new Label();
            Tues = new Label();
            Wed = new Label();
            Thurs = new Label();
            Fri = new Label();
            Sat = new Label();
            Submit = new Button();
            Reset = new Button();
            Lookup = new Button();
            SelectLbl = new Label();
            display = new Label();
            SuspendLayout();
            // 
            // Sun
            // 
            Sun.AutoSize = true;
            Sun.BackColor = Color.DarkMagenta;
            Sun.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Sun.ForeColor = SystemColors.ButtonHighlight;
            Sun.Location = new Point(32, 35);
            Sun.Name = "Sun";
            Sun.Size = new Size(83, 26);
            Sun.TabIndex = 0;
            Sun.Text = "Sunday";
            // 
            // SunText
            // 
            SunText.BackColor = Color.Thistle;
            SunText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            SunText.ForeColor = SystemColors.ButtonHighlight;
            SunText.Location = new Point(32, 77);
            SunText.Name = "SunText";
            SunText.Size = new Size(96, 34);
            SunText.TabIndex = 1;
            // 
            // MonText
            // 
            MonText.BackColor = Color.Thistle;
            MonText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            MonText.ForeColor = SystemColors.ButtonHighlight;
            MonText.Location = new Point(147, 77);
            MonText.Name = "MonText";
            MonText.Size = new Size(96, 34);
            MonText.TabIndex = 2;
            // 
            // TuesText
            // 
            TuesText.BackColor = Color.Thistle;
            TuesText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            TuesText.ForeColor = SystemColors.ButtonHighlight;
            TuesText.Location = new Point(268, 77);
            TuesText.Name = "TuesText";
            TuesText.Size = new Size(96, 34);
            TuesText.TabIndex = 3;
            // 
            // WedText
            // 
            WedText.BackColor = Color.Thistle;
            WedText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            WedText.ForeColor = SystemColors.ButtonHighlight;
            WedText.Location = new Point(386, 77);
            WedText.Name = "WedText";
            WedText.Size = new Size(96, 34);
            WedText.TabIndex = 4;
            // 
            // ThursText
            // 
            ThursText.BackColor = Color.Thistle;
            ThursText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            ThursText.ForeColor = SystemColors.ButtonHighlight;
            ThursText.Location = new Point(506, 77);
            ThursText.Name = "ThursText";
            ThursText.Size = new Size(96, 34);
            ThursText.TabIndex = 5;
            // 
            // FriText
            // 
            FriText.BackColor = Color.Thistle;
            FriText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            FriText.ForeColor = SystemColors.ButtonHighlight;
            FriText.Location = new Point(624, 77);
            FriText.Name = "FriText";
            FriText.Size = new Size(96, 34);
            FriText.TabIndex = 6;
            // 
            // SatText
            // 
            SatText.BackColor = Color.Thistle;
            SatText.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            SatText.ForeColor = SystemColors.ButtonHighlight;
            SatText.Location = new Point(747, 77);
            SatText.Name = "SatText";
            SatText.Size = new Size(96, 34);
            SatText.TabIndex = 7;
            // 
            // Entry
            // 
            Entry.AcceptsTab = true;
            Entry.BackColor = Color.Thistle;
            Entry.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Entry.ForeColor = SystemColors.ButtonHighlight;
            Entry.Location = new Point(386, 170);
            Entry.Name = "Entry";
            Entry.Size = new Size(113, 34);
            Entry.TabIndex = 8;
            // 
            // Mon
            // 
            Mon.AutoSize = true;
            Mon.BackColor = Color.DarkMagenta;
            Mon.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Mon.ForeColor = SystemColors.ButtonHighlight;
            Mon.Location = new Point(147, 35);
            Mon.Name = "Mon";
            Mon.Size = new Size(89, 26);
            Mon.TabIndex = 9;
            Mon.Text = "Monday";
            // 
            // Tues
            // 
            Tues.AutoSize = true;
            Tues.BackColor = Color.DarkMagenta;
            Tues.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Tues.ForeColor = SystemColors.ButtonHighlight;
            Tues.Location = new Point(268, 35);
            Tues.Name = "Tues";
            Tues.Size = new Size(90, 26);
            Tues.TabIndex = 10;
            Tues.Text = "Tuesday";
            // 
            // Wed
            // 
            Wed.AutoSize = true;
            Wed.BackColor = Color.DarkMagenta;
            Wed.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Wed.ForeColor = SystemColors.ButtonHighlight;
            Wed.Location = new Point(379, 35);
            Wed.Name = "Wed";
            Wed.Size = new Size(121, 26);
            Wed.TabIndex = 11;
            Wed.Text = "Wednesday";
            // 
            // Thurs
            // 
            Thurs.AutoSize = true;
            Thurs.BackColor = Color.DarkMagenta;
            Thurs.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Thurs.ForeColor = SystemColors.ButtonHighlight;
            Thurs.Location = new Point(506, 35);
            Thurs.Name = "Thurs";
            Thurs.Size = new Size(102, 26);
            Thurs.TabIndex = 12;
            Thurs.Text = "Thursday";
            // 
            // Fri
            // 
            Fri.AutoSize = true;
            Fri.BackColor = Color.DarkMagenta;
            Fri.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Fri.ForeColor = SystemColors.ButtonHighlight;
            Fri.Location = new Point(633, 35);
            Fri.Name = "Fri";
            Fri.Size = new Size(74, 26);
            Fri.TabIndex = 13;
            Fri.Text = "Friday";
            // 
            // Sat
            // 
            Sat.AutoSize = true;
            Sat.BackColor = Color.DarkMagenta;
            Sat.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Sat.ForeColor = SystemColors.ButtonHighlight;
            Sat.Location = new Point(747, 35);
            Sat.Name = "Sat";
            Sat.Size = new Size(98, 26);
            Sat.TabIndex = 14;
            Sat.Text = "Saturday";
            // 
            // Submit
            // 
            Submit.BackColor = Color.DarkMagenta;
            Submit.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Submit.ForeColor = SystemColors.ButtonHighlight;
            Submit.Location = new Point(889, 57);
            Submit.Name = "Submit";
            Submit.Size = new Size(112, 71);
            Submit.TabIndex = 15;
            Submit.Text = "Submit";
            Submit.UseVisualStyleBackColor = false;
            Submit.Click += Submit_Click_1;
            // 
            // Reset
            // 
            Reset.BackColor = Color.DarkMagenta;
            Reset.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Reset.ForeColor = SystemColors.ButtonHighlight;
            Reset.Location = new Point(889, 150);
            Reset.Name = "Reset";
            Reset.Size = new Size(112, 71);
            Reset.TabIndex = 16;
            Reset.Text = "Reset";
            Reset.UseVisualStyleBackColor = false;
            Reset.Click += Reset_Click;
            // 
            // Lookup
            // 
            Lookup.BackColor = Color.DarkMagenta;
            Lookup.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            Lookup.ForeColor = SystemColors.ButtonHighlight;
            Lookup.Location = new Point(535, 150);
            Lookup.Name = "Lookup";
            Lookup.Size = new Size(112, 71);
            Lookup.TabIndex = 17;
            Lookup.Text = "Lookup";
            Lookup.UseVisualStyleBackColor = false;
            Lookup.Click += Lookup_Click_1;
            // 
            // SelectLbl
            // 
            SelectLbl.AutoSize = true;
            SelectLbl.BackColor = Color.DarkMagenta;
            SelectLbl.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            SelectLbl.ForeColor = SystemColors.ButtonHighlight;
            SelectLbl.Location = new Point(44, 173);
            SelectLbl.Name = "SelectLbl";
            SelectLbl.Size = new Size(320, 26);
            SelectLbl.TabIndex = 18;
            SelectLbl.Text = "Select day to see time submitted";
            // 
            // display
            // 
            display.AutoSize = true;
            display.BackColor = Color.DarkMagenta;
            display.Font = new Font("Sylfaen", 10F, FontStyle.Bold, GraphicsUnit.Point);
            display.ForeColor = SystemColors.ButtonHighlight;
            display.Location = new Point(358, 275);
            display.Name = "display";
            display.Size = new Size(0, 26);
            display.TabIndex = 19;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1064, 450);
            Controls.Add(display);
            Controls.Add(SelectLbl);
            Controls.Add(Lookup);
            Controls.Add(Reset);
            Controls.Add(Submit);
            Controls.Add(Sat);
            Controls.Add(Fri);
            Controls.Add(Thurs);
            Controls.Add(Wed);
            Controls.Add(Tues);
            Controls.Add(Mon);
            Controls.Add(Entry);
            Controls.Add(SatText);
            Controls.Add(FriText);
            Controls.Add(ThursText);
            Controls.Add(WedText);
            Controls.Add(TuesText);
            Controls.Add(MonText);
            Controls.Add(SunText);
            Controls.Add(Sun);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = SystemColors.ControlText;
            FormBorderStyle = FormBorderStyle.SizableToolWindow;
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Sun;
        private TextBox SunText;
        private TextBox MonText;
        private TextBox TuesText;
        private TextBox WedText;
        private TextBox ThursText;
        private TextBox FriText;
        private TextBox SatText;
        private TextBox Entry;
        private Label Mon;
        private Label Tues;
        private Label Wed;
        private Label Thurs;
        private Label Fri;
        private Label Sat;
        private Button Submit;
        private Button Reset;
        private Button Lookup;
        private Label SelectLbl;
        private Label display;
    }
}